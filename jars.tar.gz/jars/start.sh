./tfg-caster.sh &
./tfgcounter.sh &
./tfgposter.sh &
