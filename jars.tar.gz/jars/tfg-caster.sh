java -jar tfg-caster.jar 192.168.1.108:9092 caster crash 192.168.1.108:9092 crashout
