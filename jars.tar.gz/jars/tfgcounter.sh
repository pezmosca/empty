java -jar tfgcounter.jar 192.168.1.108:9092 counter crashout crashcount
