java -jar tfgposter.jar 192.168.1.108:9092 poster crashcount 2 192.168.1.115:8080 REST 10004
